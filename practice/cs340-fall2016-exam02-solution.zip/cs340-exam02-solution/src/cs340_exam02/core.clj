(ns cs340-exam02.core)

;; Question 1 [30 points].
;;
;; This function takes two parameters: a three-element vector v
;; and an integer n.  If n is even, then the function should
;; return a vector with the first and second elements of v swapped.
;; If n is odd, then the function should return a vector with
;; the second and third elements of v swapped.
;;
;; Parameters:
;;    v - a vector with 3 elements
;;    n - an integer
;;
;; Returns:
;;    if n is even, a vector with the first and second elements of v swapped;
;;    if n is odd, a vector with the second and third elements of v swapped
;;
;; Hints/specifications:
;;    - consider destructuring the vector
;;    - the mod function returns the remainder after integer division,
;;      e.g., (mod 4 2) => 0 and (mod 5 2) => 1
;;
;; Examples:
;;    (juggle [:a :b :c] 0) => [:b :a :c]
;;    (juggle [:b :a :c] 1) => [:b :c :a]
;;    (juggle [:b :c :a] 2) => [:c :b :a]
;;    (juggle [:c :b :a] 3) => [:c :a :b]
;;    (juggle ["red" "green" "blue"] 49) => ["red" "blue" "green"]
;;
(defn juggle [v n]
  (let [[a b c] v]
    (if (= (mod n 2) 0)
      [b a c]
      [a c b])))
;  "The growth of wisdom may be gauged exactly by the diminution of ill temper.")


;; Question 2 [20 points].
;;
;; This function takes two integers, q and n.
;; It should return a sequence containing the first 
;; n multiples of q, starting with q.
;;
;; Parameters:
;;    q - an integer
;;    n - a non-negative integer
;;
;; Returns:
;;    sequence with the first n multiples of q, starting with q
;;
;; Hints/specifications:
;;   - your solution *must* use tail recursion
;;   - suggestion: use loop/recur
;;   - suggestion: use two loop variables, a count (starting at 1)
;;     and an accumulator (initially an empty sequence)
;;   - think about what your base case should be
;;   - think about how to update the loop variables in the recursive case
;;
;; Examples:
;;    (generate-multiples 3 4) => [3 6 9 12]
;;    (generate-multiples 2 10) => [2 4 6 8 10 12 14 16 18 20]
;;    (generate-multiples 5 1) => [5]
;;    (generate-multiples 11 5) => [11 22 33 44 55]
;;    (generate-multiples -4 5) => [-4 -8 -12 -16 -20]
;;    (generate-multiples 9 0) => []
;;
(defn generate-multiples [q n]
  (loop [ct 1
         acc []]
    (if (> ct n)
      acc
      (recur (inc ct) (conj acc (* q ct))))))
;  "You must have chaos within you to give birth to a dancing star.")


;; Question 3 [20 points].
;;
;; This function takes a function f and a non-negative integer
;; n, and returns a function which applies f to n copies of
;; its argument.
;;
;; Parameters:
;;    f - a function
;;    n - a non-negative integer
;;
;; Returns:
;;    a function which returns the result of applying f to n copies
;;    of its argument
;;
;; Hints/specifications:
;;    - since make-multi-applicator returns a function, its body
;;      should be an fn form
;;    - (repeat n x) returns a sequence containing n copies of x
;;    - use the built-in apply function to apply the function
;;      to the arguments (n copies of the returned function's argument):
;;      you should remember using apply in the "Structured data"
;;      chapter of the Clojure MOOC
;;
;; Examples:
;;    ((make-multi-applicator list 4) :a) => (:a :a :a :a)
;;    ((make-multi-applicator vector 4) :a) => [:a :a :a :a]
;;    ((make-multi-applicator + 3) 2) => 6
;;    ((make-multi-applicator * 3) 2) => 8
;;
(defn make-multi-applicator [f n]
  (fn [x]
    (apply f (repeat n x))))
  ;  "Is not life a hundred times too short to bore ourselves?")


;; Question 4 [20 points].
;;
;; This function takes two parameters: a predicate function pred
;; and a sequence a-seq.  It returns a count the number of
;; elements of a-seq for which the predicate function returns
;; a true value.  (I.e., the predicate function is applied to
;; each value in the sequence, and the overall function returns
;; a count of how many times the predicate returned a true value.)
;;
;; Parameters:
;;     pred - a predicate function (takes a single argument and returns
;;            a boolean value)
;;     a-seq - a sequence of values
;;
;; Returns:
;;    an integer count of the number of elements in the sequence
;;    for which the predicate returned a true value
;;
;; Hints/specifications:
;;     - you may implement this function however you would like
;;     - a tail recursion using loop/recur is a good approach
;;       (but is not the only possible approach)
;;
;; Examples:
;;    (count-matching even? [1 2 3 4 5]) => 2
;;    (count-matching (fn [x] (= x :spam)) [:spam :spam :eggs :spam :baked-beans :spam :spam])
;;       => 2
;;    (count-matching sequential? [:a :b [:c] :d [:e :f] '(:g)]) => 3
;;
(defn count-matching [pred a-seq]
  (loop [remaining a-seq
         count 0]
    (if (empty? remaining)
      count
      (recur (rest remaining) (+ (if (pred (first remaining)) 1 0) count)))))
;  "Thoughts are the shadows of our feelings - always darker, emptier and simpler.")


;; Question 5 [10 points].
;;
;; This function takes two parameters: f-seq, a sequence
;; of functions accepting one argument, and val, a starting value.
;; It returns the result of applying the first function
;; to val, then applying the second function to the result
;; of the first, etc.  As a special case, if the sequence
;; of functions is empty, just return val.
;;
;; Parameters:
;;    f-seq - sequence of functions (each function can be
;;            called on a single argument to produce a single
;;            result value)
;;    val - a starting value
;;
;; Returns:
;;    the result produced by starting with val and then applying
;;    each function in the sequence
;;
;; Hints/specifications:
;;    - your solution *must* use tail recursion
;;    - suggestion: use loop/recur
;;    - suggestion: use two loop variables, one for the remaining
;;      functions to apply, one an accumulator (which initial value
;;      should be val)
;;    - think about a base case and recursive case
;;
;; Examples:
;;    (apply-fn-chain [] 4) => 4
;;    (apply-fn-chain [inc inc (fn [x] (* x 2))] 4) => 12
;;    (apply-fn-chain [reverse list] [:a :b :c]) => ((:c :b :a))
;;    (apply-fn-chain [count (fn [x] (* x 10)) dec] ["spicy" "prawns"]) => 19
;;
(defn apply-fn-chain [f-seq val]
  (loop [rem f-seq
	        acc val]
	   (if (empty? rem)
	     acc
	     (recur (rest rem) ((first rem) acc)))))
; "When you look into an abyss, the abyss also looks into you.")


;; Bonus question [10 points].
;;
;; This function takes two parameters: a three-element vector v
;; and an integer n.  It returns a sequence where:
;;
;;   - the first member (if any) is v
;;
;;   - each subsequent member is the result of
;;
;;        (juggle x m)
;;
;;     where x is the previous element of the sequence, and
;;     x is either an even number or an odd number as follows.
;;     If x is the first, third, fifth, etc. member of the sequence,
;;     m should be odd.  If x is the second, fourth, sixth, etc.
;;     member of the sequence, m should be even.
;;
;; The result sequence should have exactly n members.
;;
;; Parameters:
;;    v - a three-element vector
;;    n - an integer
;;
;; Returns:
;;    a sequence of values as described above
;;
;; Hints/specifications:
;;    - use loop/recur
;;    - use three loop variables: a count which starts at 0,
;;      a "next element to append" whose initial value is v, and
;;      an accumulator which is initially the empty vector
;;    - return the accumulator if the base case is reached
;;    - each recursive call (recur) should use the juggle function
;;      to generate the next "next element to append" value
;;
;; Examples:
;;    (circus [:a :b :c] 0) => []
;;    (circus [:a :b :c] 1) => [[:a :b :c]]
;;    (circus [:a :b :c] 2) => [[:a :b :c] [:b :a :c]]
;;    (circus [:a :b :c] 3) => [[:a :b :c] [:b :a :c] [:b :c :a]]
;;
(defn circus [v n]
  (loop [ct 0
         x v
         acc []]
    (if (= ct n)
      acc
      (recur (inc ct)
             (juggle x ct)
             (conj acc x)))))
;  "Existence really is an imperfect tense that never becomes a present.")
