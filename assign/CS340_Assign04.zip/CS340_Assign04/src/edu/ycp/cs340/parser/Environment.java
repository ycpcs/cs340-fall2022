package edu.ycp.cs340.parser;

import java.util.HashMap;
import java.util.Map;

/**
 * An environment is a collection of bindings of names to
 * {@link Value}s.  Each environment can have a parent
 * environment.  In looking for a value associated with a
 * name, if the name isn't found in the current environment,
 * then the search continues recursively in the parent environment.
 */
public class Environment {
	private Environment parent;
	private Map<String, Value> bindings;
	
	public Environment(Environment parent) {
		this.parent = parent;
		this.bindings = new HashMap<>();
	}
	
	/**
	 * Search for a binding for the specified name,
	 * starting with this environment, and if there is no
	 * binding in the current environment, continuing the
	 * search recursively in the parent environment.
	 * 
	 * @param name the name to look up
	 * @return the {@link Value} to which the name is bound
	 * @throws EvaluationException if the name is not bound to a value
	 */
	public Value lookup(String name) {
		Value value = bindings.get(name);
		if (value != null) {
			// found a binding
			return value;
		}
		// Try to find a binding for the name in the parent environment.
		// If there is no parent environment, then we've proved
		// that the name is not bound.
		if (parent == null) {
			throw new EvaluationException("No binding for name " + name);
		}
		return parent.lookup(name);
	}

	/**
	 * Add or modify the binding for the specified name
	 * in this environment.
	 * 
	 * @param name   the name (i.e., a variable name)
	 * @param value  the {@link Value} to which the name should be bound
	 */
	public void put(String name, Value value) {
		bindings.put(name, value);
	}
}
