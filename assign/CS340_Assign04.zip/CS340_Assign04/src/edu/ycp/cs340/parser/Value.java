package edu.ycp.cs340.parser;

import java.util.List;

/**
 * This interface defines run-time values in the interpreter.
 */
public interface Value {
	/**
	 * Get the {@link ValueType} of this value.
	 * 
	 * @return the {@link ValueType}
	 */
	public ValueType getType();
	
	/**
	 * Get the numeric value.  Will throw an exception
	 * if this value isn't a {@link NumberValue}.
	 * 
	 * @return the numeric value
	 * @throws EvaluationException if this isn't a {@link NumberValue}
	 */
	public int getNumber();
	
	/**
	 * Get the function body of this function.
	 * Will throw an exception if this value isn't a
	 * {@link FunctionValue}.
	 * 
	 * @return the function body
	 * @throws EvaluationException if this isn't a {@link FunctionValue}
	 */
	public Node getFunctionBody();
	
	/**
	 * Get the list of function parameter names.
	 * Will throw an exception if this value isn't a
	 * {@link FunctionValue}.
	 * 
	 * @return the list of parameter names
	 * @throws EvaluationException if this isn't a {@link FunctionValue}
	 */
	public List<String> getFunctionParameters();
}
