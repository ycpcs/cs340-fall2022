package edu.ycp.cs340.parser;

import java.io.StringReader;
import java.util.Scanner;

/**
 * The class provides a main function that runs a read/eval/print
 * loop to read expressions, evaluate them, and print the result
 * of evaluation.  The parse tree of each expression is also
 * printed.
 */
public class Main {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Enter expressions (type 'quit' when finished):");
		
		Interpreter interpreter = new Interpreter();
		
		boolean done = false;
		while (!done) {
			System.out.print("> ");
			if (!keyboard.hasNextLine()) {
				done = true;
			} else {
				String line = keyboard.nextLine();
				if (line == null) {
					done = true;
				} else {
					line = line.trim();
					if (line.toLowerCase().equals("quit")) {
						done = true;
					} else {
						StringReader sr = new StringReader(line);
						Lexer lexer = new Lexer(sr);
						Parser parser = new Parser(lexer);
						Node parseTree = parser.parse();
						TreePrinter tp = new TreePrinter();
						tp.print(parseTree);

						// Make sure that if an exception is thrown evaluating the
						// expression, the Eclipse console has time to finish
						// printing the parse tree.
						pause();
						
						Value result = interpreter.evaluate(parseTree);
						
						System.out.println("=> " + result);
					}
				}
			}
		}
	}
	
	private static final void pause() {
		try {
			Thread.sleep(5);
		} catch (InterruptedException e) {
			// ignore
		}
	}
}
