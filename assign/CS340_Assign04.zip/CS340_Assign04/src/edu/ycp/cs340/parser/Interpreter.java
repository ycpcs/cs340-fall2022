package edu.ycp.cs340.parser;

/**
 * Interpreter class.
 * An interpreter object maintains a global environment for global
 * variables and functions, and supports evaluating arbitrary
 * expressions in the global environment.
 */
public class Interpreter {
	private Environment globalEnv;
	
	/**
	 * Constructor.
	 */
	public Interpreter() {
		globalEnv = new Environment(null);
		globalEnv.put("theAnswer", new NumberValue(42));
	}
	
	/**
	 * Evaluate an expression in the global environment.
	 * You will not need to modify this method.
	 * 
	 * @param expr  the expression to evaluate
	 * @return the {@link Value} resulting from evaluating the expression
	 * @throws EvaluationException if an error occurs in evaluation
	 */
	public Value evaluate(Node expr) {
		return evaluate(expr, globalEnv);
	}

	/**
	 * Evaluate an expression in the specified environment.
	 * You will need to modify this method to handle evaluation of the
	 * various types of expressions.  This is the method you
	 * should call recursively in order to evaluate a subexpression.
	 * 
	 * @param expr  the expression to evaluate
	 * @return the {@link Value} resulting from evaluating the expression
	 * @throws EvaluationException if an error occurs in evaluation
	 */
	private Value evaluate(Node expr, Environment env) {
		switch (expr.getSymbol()) {
		case PRIMARY:
			// Note that parenthesized subexpressions, functions, and function calls
			// all appear as PRIMARY nodes.  You will need to use the number of
			// children and/or the symbol of the first child to determine how to
			// handle each different kind of PRIMARY node.
			if (expr.getChildren().size() == 1) {
				return evaluate(expr.getChildren().get(0), env);
			} else {
				throw new UnsupportedOperationException("TODO: handle PRIMARY expressions with multiple children");
			}
		
		case INT_LITERAL:
			return new NumberValue(Integer.valueOf(expr.getToken().getLexeme()));
			
		default:
			throw new UnsupportedOperationException("Unhandled expression type: " + expr.getSymbol());
		}
	}
}
