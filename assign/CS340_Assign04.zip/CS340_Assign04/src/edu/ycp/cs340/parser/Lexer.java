package edu.ycp.cs340.parser;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;
import java.util.function.Predicate;

public class Lexer {
	private PushbackReader r;
	private Token next;
	
	public Lexer(Reader r) {
		this.r = new PushbackReader(r);
		this.next = null;
	}
	
	public Token peek() {
		fill();
		return next;
	}
	
	public Token next() {
		fill();
		if (next == null) {
			throw new LexerException("Unexpected end of input");
		}
		Token result = next;
		next = null;
		return result;
	}
	
	private static final String LEGAL = "+-*/^(){}=,";

	private void fill() {
		try {
			doFill();
		} catch (IOException e) {
			throw new LexerException("IOException looking for token", e);
		}
	}

	/**
	 * @throws IOException
	 */
	public void doFill() throws IOException {
		while (next == null) {
			int c = r.read();
			if (c < 0) {
				// Reached end of input
				return;
			}
			if (!Character.isWhitespace(c)) {
				if (LEGAL.indexOf(c) >= 0) {
					next = new Token((char)c);
				} else if (Character.isLetter(c)) {
					next = readToken(c, Symbol.IDENTIFIER, (Integer x) -> Character.isJavaIdentifierPart(x));
					if (next.getLexeme().equals("fn")) {
						next.setSymbol(Symbol.FN_KEYWORD);
					}
				} else if (Character.isDigit(c)) {
					next = readToken(c, Symbol.INT_LITERAL, (Integer x) -> Character.isDigit(x));
				} else {
					throw new LexerException("Unknown character: " + ((char)c));
				}
			}
		}
	}

	private Token readToken(int c, Symbol symbol, Predicate<Integer> pred) throws IOException {
		StringBuffer buf = new StringBuffer();
		buf.append((char)c);
		
		while (true) {
			c = r.read();
			if (c < 0) {
				break;
			}
			if (!pred.test(c)) {
				r.unread(c);
				break;
			}
			buf.append((char)c);
		}
		
		return new Token(symbol, buf.toString());
	}
}
