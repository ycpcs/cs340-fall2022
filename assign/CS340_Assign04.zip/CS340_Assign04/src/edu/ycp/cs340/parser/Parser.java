package edu.ycp.cs340.parser;

public class Parser {
	public enum Associativity {
		LEFT,
		RIGHT,
	}
	
	private Lexer lexer;
	
	public Parser(Lexer lexer) {
		this.lexer = lexer;
	}
	
	public Node parse() {
		return parse1(parsePrimary(), 0);
	}
	
	private Node parse1(Node lhs, int minPrecedence) {
		// while the next token is a binary operator whose precedence is >= min_precedence
		while (true) {
			Token op = lexer.peek();
			if (op == null || !isOp(op) || prec(op) < minPrecedence) {
				break;
			}
			lexer.next(); // consume operator token

			Node rhs = parsePrimary();

			// while the next token is
			//   (1) a binary operator whose precedence is greater than op's, or
			//   (2) a right-associative operator whose precedence is equal to op's
			while (true) {
				Token lookahead = lexer.peek();
				if (lookahead == null ||
					!isOp(lookahead) ||
					!(prec(lookahead) > prec(op) ||
					  assoc(lookahead) == Associativity.RIGHT && prec(lookahead) == prec(op))) {
					break;
				} else {
					rhs = parse1(rhs, prec(lookahead));
				}
			}
			
			Node n = new Node(op.getSymbol());
			n.getChildren().add(lhs);
			n.getChildren().add(rhs);
			lhs = n;
		}
		
		return lhs;
	}

	// Is given token an operator?
	private boolean isOp(Token tok) {
		switch (tok.getSymbol()) {
		case ASSIGN:
		case PLUS:
		case MINUS:
		case TIMES:
		case DIVIDES:
		case EXP:
			return true;
		default:
			return false;
		}
	}

	// Get precedence of given operator token
	private int prec(Token op) {
		switch (op.getSymbol()) {
		case ASSIGN:
			return 0;
		case PLUS:
		case MINUS:
			return 1;
		case TIMES:
		case DIVIDES:
			return 2;
		case EXP:
			return 3;
		default:
			throw new IllegalArgumentException(op + " is not an operator");
		}
	}

	// Get associativity of given operator token
	private Associativity assoc(Token op) {
		switch (op.getSymbol()) {
		case PLUS:
		case MINUS:
		case TIMES:
		case DIVIDES:
			return Associativity.LEFT;
		case ASSIGN:
		case EXP:
			return Associativity.RIGHT;
		default:
			throw new IllegalArgumentException(op + " is not an operator");
		}
	}

	private Node parsePrimary() {
		Node f = new Node(Symbol.PRIMARY);
		
		Token tok = lexer.next();
		
		if (tok.getSymbol() == Symbol.INT_LITERAL) {
			// 	Primary → int_literal	
			f.getChildren().add(new Node(tok));
		} else if (tok.getSymbol() == Symbol.IDENTIFIER) {
			// 	Primary -> ^ identifier
			//  Primary -> ^ identifier ( OptArgumentList )
			f.getChildren().add(new Node(tok));
			tok = lexer.peek();
			if (tok != null && tok.getSymbol() == Symbol.LPAREN) {
				//  Primary -> identifier ^ ( OptArgumentList )
				f.getChildren().add(expect(Symbol.LPAREN));
				f.getChildren().add(parseOptArgumentList());
				f.getChildren().add(expect(Symbol.RPAREN));
			}
		} else if (tok.getSymbol() == Symbol.LPAREN) {
			// Primary -> ( expression )
			f.getChildren().add(new Node(tok));
			f.getChildren().add(parse());
			f.getChildren().add(expect(Symbol.RPAREN));
		} else if (tok.getSymbol() == Symbol.FN_KEYWORD) {
			// Primary -> fn ( OptParameterList ) { expression }
			f.getChildren().add(new Node(tok));
			f.getChildren().add(expect(Symbol.LPAREN));
			f.getChildren().add(parseOptParameterList());
			f.getChildren().add(expect(Symbol.RPAREN));
			f.getChildren().add(expect(Symbol.LBRACE));
			f.getChildren().add(parse());
			f.getChildren().add(expect(Symbol.RBRACE));
		} else {
			throw new ParserException("Unexpected symbol looking for primary expression: " + tok);
		}
		
		return f;
	}
	
	private Node parseOptArgumentList() {
		Node optArgList = new Node(Symbol.OPT_ARGUMENT_LIST);
		
		// OptArgumentList -> epsilon
		// OptArgumentList -> ArgumentList
		Token tok = lexer.peek();
		if (tok == null || tok.getSymbol() == Symbol.RPAREN) {
			// OptArgumentList -> epsilon
		} else {
			// OptArgumentList -> ArgumentList
			optArgList.getChildren().add(parseArgumentList());
		}
		
		return optArgList;
	}
	
	private Node parseArgumentList() {
		Node argList = new Node(Symbol.ARGUMENT_LIST);
		
		// ArgumentList -> ^ expression
		// ArgumentList -> ^ expression ',' ArgumentList
		
		argList.getChildren().add(parse());
		Token tok = lexer.peek();
		if (tok != null && tok.getSymbol() == Symbol.COMMA) {
			// ArgumentList -> expression ^ ',' ArgumentList
			argList.getChildren().add(expect(Symbol.COMMA));
			argList.getChildren().add(parseArgumentList());
		}
		
		return argList;
	}
	
	private Node parseOptParameterList() {
		Node optParamList = new Node(Symbol.OPT_PARAMETER_LIST);
		
		// OptParameterList -> epsilon
		// OptParameterList -> ParameterList
		
		Token tok = lexer.peek();
		if (tok == null || tok.getSymbol() == Symbol.RPAREN) {
			// OptParameterList -> epsilon
		} else {
			// OptParameterList -> ParameterList
			optParamList.getChildren().add(parseParameterList());
		}
		
		return optParamList;
	}
	
	private Node parseParameterList() {
		Node paramList = new Node(Symbol.PARAMETER_LIST);
		
		// ParameterList -> ^ identifier
		// ParameterList -> ^ identifier , ParameterList
		paramList.getChildren().add(expect(Symbol.IDENTIFIER));
		Token tok = lexer.peek();
		if (tok != null && tok.getSymbol() == Symbol.COMMA) {
			// ParameterList -> identifier ^ , ParameterList
			paramList.getChildren().add(expect(Symbol.COMMA));
			paramList.getChildren().add(parseParameterList());
		}
		
		return paramList;
	}

	private Node expect(Symbol expected) {
		Token tok = lexer.next();
		if (tok.getSymbol() != expected) {
			throw new ParserException("Unexpected token: saw " + tok.getSymbol() + ", expected " + expected);
		}
		return new Node(tok);
	}
}
