package edu.ycp.cs340.parser;

/**
 * Enumerated type for distinguishing the different kinds
 * of {@link Value} objects.
 */
public enum ValueType {
	/** Used for {@link NumberValue}s. */
	NUMBER,
	/** Used for {@link FunctionValue}s. */
	FUNCTION,
}
