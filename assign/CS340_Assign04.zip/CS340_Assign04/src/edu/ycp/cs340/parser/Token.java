package edu.ycp.cs340.parser;

public class Token {
	private Symbol symbol;
	private String lexeme;
	
	public Token(int c) {
		this.symbol = Symbol.fromCharacter(c);
		this.lexeme = "" + ((char)c);
	}
	
	public Token(Symbol symbol, String lexeme) {
		this.symbol = symbol;
		this.lexeme = lexeme;
	}

	public String getLexeme() {
		return lexeme;
	}
	
	public Symbol getSymbol() {
		return symbol;
	}
	
	public void setSymbol(Symbol symbol) {
		this.symbol = symbol;
	}
	
	@Override
	public String toString() {
		return lexeme;
	}
}
