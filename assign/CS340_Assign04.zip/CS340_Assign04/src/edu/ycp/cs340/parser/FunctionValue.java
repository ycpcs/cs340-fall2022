package edu.ycp.cs340.parser;

import java.util.Collections;
import java.util.List;

/**
 * This kind of value represents a function with some number
 * of parameters and an expression as the function's body.
 */
public class FunctionValue implements Value {
	private Node body;
	private List<String> parameters;

	/**
	 * Constructor.
	 * 
	 * @param body        the body expression
	 * @param parameters  list of parameter names
	 */
	public FunctionValue(Node body, List<String> parameters) {
		this.body = body;
		this.parameters = Collections.unmodifiableList(parameters);
	}
	
	@Override
	public ValueType getType() {
		return ValueType.FUNCTION;
	}

	@Override
	public int getNumber() {
		throw new EvaluationException("FunctionValue has no numeric value");
	}

	@Override
	public Node getFunctionBody() {
		return this.body;
	}

	@Override
	public List<String> getFunctionParameters() {
		return this.parameters;
	}
	
	@Override
	public String toString() {
		return "<<function>>";
	}
}
