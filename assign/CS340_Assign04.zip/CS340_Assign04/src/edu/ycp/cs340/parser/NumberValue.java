package edu.ycp.cs340.parser;

import java.util.List;

/**
 * A number value object represents an integer value.
 */
public class NumberValue implements Value {
	private int value;

	/**
	 * Constructor.
	 * 
	 * @param value  the integer value
	 */
	public NumberValue(int value) {
		this.value = value;
	}
	
	@Override
	public ValueType getType() {
		return ValueType.NUMBER;
	}

	@Override
	public int getNumber() {
		return this.value;
	}

	@Override
	public Node getFunctionBody() {
		throw new EvaluationException("NumberValue has no function body");
	}

	@Override
	public List<String> getFunctionParameters() {
		throw new EvaluationException("NumberValue has no function parameters");
	}
	
	@Override
	public String toString() {
		return String.valueOf(this.value);
	}
}
