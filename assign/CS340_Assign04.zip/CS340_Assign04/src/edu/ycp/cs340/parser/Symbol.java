package edu.ycp.cs340.parser;

public enum Symbol {
	// Terminal symbols
	IDENTIFIER,
	FN_KEYWORD,
	INT_LITERAL,
	PLUS,
	MINUS,
	TIMES,
	DIVIDES,
	EXP,
	LPAREN,
	RPAREN,
	LBRACE,
	RBRACE,
	ASSIGN,
	COMMA,
	
	// Nonterminal symbols
	PRIMARY,
	OPT_ARGUMENT_LIST,
	ARGUMENT_LIST,
	OPT_PARAMETER_LIST,
	PARAMETER_LIST
	;
	
	/**
	 * Convert a single character value to a (terminal) Symbol.
	 * 
	 * @param ch a character
	 * @return the Symbol
	 */
	public static Symbol fromCharacter(int ch) {
		switch (ch) {
		case '+':
			return PLUS;
		case '-':
			return MINUS;
		case '*':
			return TIMES;
		case '/':
			return DIVIDES;
		case '^':
			return EXP;
		case '(':
			return LPAREN;
		case ')':
			return RPAREN;
		case '{':
			return LBRACE;
		case '}':
			return RBRACE;
		case '=':
			return ASSIGN;
		case ',':
			return COMMA;
		default:
			throw new LexerException("Unknown character: " + ((char)ch));
		}
	}
}
