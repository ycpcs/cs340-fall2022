(ns minilang.lexer
  (:require [catparty.lexer :as lexer]))

;; Regular expressions defining the token types
(def token-patterns
  [; Keywords
   [#"^var" :var]
   [#"^func" :func]
   [#"^if" :if]
   [#"^while" :while]

   ; Identifiers   
   [#"^[A-Za-z_][A-Za-z0-9_]*" :identifier]

   ; Literals
   [#"^\"(\\\"|\\\\|[^\\\\\"])*?\"" :str_literal]
   [#"^[0-9]+" :int_literal]

   ; Operators
   [#"^:=" :op_assign]
   [#"^\+" :op_plus]
   [#"^-" :op_minus]
   [#"^\*" :op_mul]
   [#"^/" :op_div]
   [#"^\^" :op_exp]
   [#"^<=" :op_lte]
   [#"^<" :op_lt]
   [#"^>=" :op_gte]
   [#"^>" :op_gt]
   [#"^=" :op_eq]
   [#"^!=" :op_neq]   

   ; Punctuation
   [#"^;" :semicolon]
   [#"^\(" :lparen]
   [#"^\)" :rparen]
   [#"^\{" :lbrace]
   [#"^\}" :rbrace]
   ])

;; Create a lexer from a string containing Minilang code.
(defn create-from-string [s]
  (lexer/create-from-string s token-patterns))
